//ignore this

document.addEventListener("DOMContentLoaded", function(event) {
    console.log("DOM fully loaded and parsed");

    document.getElementById("neighborhoods-select").tabIndex = "1";
    document.getElementById("cuisines-select").tabIndex = "2";

    var listedRestaurants = document.getElementById("restaurants-list").getElementsByTagName("li");
    var i = 2;//document.getElementById("cuisines-select").tabIndex;

    alert(document.getElementById("cuisines-select").tabIndex);

    console.log(listedRestaurants);

    for (var restaurantEntry of listedRestaurants) {
        alert("test", i, restaurantEntry);
        i++;
    }
  });