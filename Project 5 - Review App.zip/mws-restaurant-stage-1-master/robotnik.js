//Define Static Cache Name for later
var staticCacheName = 'restaurant-static-v1';

console.log("Hello from robotnik.js :-)")

//Listen for Install Event
this.addEventListener('install', function (event) {
    //Wait for Install Event to succeed
    event.waitUntil(
        //Then open v1 Cache
        caches.open('restaurant-static-v1').then(function (cache) {
            //cache these files
            return cache.addAll([
                //root of evil
                './',
                //Media Files
                './img/10.jpg',
                './img/9.jpg',
                './img/8.jpg',
                './img/7.jpg',
                './img/6.jpg',
                './img/5.jpg',
                './img/4.jpg',
                './img/3.jpg',
                './img/2.jpg',
                './img/1.jpg',
                //Data Files
                './data/restaurants.json',
                //Style Sheet
                './css/styles.css',
                //Script Files
                './js/dbhelper.js',
                './js/main.js',
                './js/restaurant_info.js',
                //HTML
                './index.html',
                './restaurant.html'//,
                //SW Files
                // '/robotnik_reg.js',
                // '/robotnik.js'
            ]);
        })
    );
});

self.addEventListener('activate', function (event) {
    console.log('hello from activate event ^^');
    console.log(caches);
    event.waitUntil(

        // Get all the cache keys as an array
        caches.keys().then(function (cacheNames) {
            return Promise.all(cacheNames.map(function (thisCacheName) {

                // If a cached item is saved under a previous cacheName
                if (thisCacheName !== staticCacheName) {

                    // Delete that cached file
                    console.log('deleting file from cache:', thisCacheName);
                    return caches.delete(thisCacheName);
                }
            }));
        })
    );

});


//Listen for Fetch event
this.addEventListener('fetch', function (event) {
    console.log("hello from fetch event", event);
    event.respondWith(
        //if there's a match with sth. from cache
        caches.match(event.request)
            //respont with corresponding file from cache
            .then(function (response) {
                console.log("event request is:", event.request);
                console.log("response is: ", response); //might undefined for some magic reason.
                return response || fetch(event.request);
            })
    );
});
