//Service Workers supported?
if ('serviceWorker' in navigator) {
    //If yes, than register Service Worker for whole site
    navigator.serviceWorker.register('./robotnik.js').then(function (reg) {
        //Registration successful:
        console.log('Robotnik registered. Scope: ' + reg.scope);
    }).catch(function (error) {
        // Registrierung fehlgeschlagen
        console.log('Robotnik Registration failed: ' + error);
    });
};


// trying w/o scope , { scope: './' }